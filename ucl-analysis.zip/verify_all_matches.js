const { UCL_DATA } = require('./data.js');

UCL_DATA.matches.forEach(m => {
  console.log(`\n=== MATCH ${m.id}: ${m.homeTeam.name} vs ${m.awayTeam.name} ===`);
  console.log(`Stadium: ${m.stadium.name} (${m.stadium.city}, ${m.stadium.country}) | File: ${m.stadium.image}`);
  console.log(`Star Duel: ${m.keyDuel.homeStar.name} (${m.keyDuel.homeStar.image}) vs ${m.keyDuel.awayStar.name} (${m.keyDuel.awayStar.image})`);
  const injuredCountHome = (m.squadRoster && m.squadRoster.home.injuredPlayers.length) || 0;
  const injuredCountAway = (m.squadRoster && m.squadRoster.away.injuredPlayers.length) || 0;
  console.log(`Injured Players: ${m.homeTeam.name} (${injuredCountHome}) | ${m.awayTeam.name} (${injuredCountAway})`);
});
