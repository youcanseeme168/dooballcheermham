# -*- coding: utf-8 -*-
import json, re

MAPPING = {
    'shaw': ['luke shaw', 'shaw'],
    'mazraoui': ['noussair mazraoui', 'mazraoui'],
    'yoro': ['leny yoro', 'yoro'],
    'ugarte': ['manuel ugarte', 'ugarte'],
    'sesko': ['benjamin šeško', 'sesko', 'seško'],
    'rashford': ['marcus rashford', 'rashford'],
    'bruno': ['bruno fernandes', 'bruno'],
    'onana': ['andré onana', 'onana'],
    'dybala': ['paulo dybala', 'dybala'],
    'malen': ['donyell malen', 'malen'],
    'svilar': ['mile svilar', 'svilar'],
    'hummels': ['mats hummels', 'hummels'],
    'saelemaekers': ['alexis saelemaekers', 'saelemaekers'],
    'dovbyk': ['artem dovbyk', 'dovbyk'],
    'osimhen': ['victor osimhen', 'osimhen'],
    'icardi': ['mauro icardi', 'icardi'],
    'demirovic': ['ermedin demirović', 'demirovic'],
    'stiller': ['angelo stiller', 'stiller'],
    'undav': ['deniz undav', 'undav'],
    'vagnoman': ['josha vagnoman', 'vagnoman'],
    'zagadou': ['dan-axel zagadou', 'zagadou'],
    'chabot': ['jeff chabot', 'chabot'],
    'sudakov': ['georgiy sudakov', 'sudakov'],
    'pedrinho': ['pedrinho'],
    'gyokeres': ['viktor gyökeres', 'gyokeres'],
    'trincao': ['francisco trincão', 'trincao'],
    'fresneda': ['iván fresneda', 'fresneda'],
    'gimenez': ['santiago giménez', 'gimenez'],
    'timber': ['quinten timber', 'timber'],
    'lautaro': ['lautaro martínez', 'lautaro'],
    'thuram': ['marcus thuram', 'thuram'],
    'barella': ['nicolò barella', 'barella'],
    'sommer': ['yann sommer', 'sommer'],
    'berg': ['patrick berg', 'berg'],
    'zinckernagel': ['philip zinckernagel', 'zinckernagel'],
    'david': ['jonathan david', 'david'],
    'zhegrova': ['edon zhegrova', 'zhegrova'],
    'chevalier': ['lucas chevalier', 'chevalier'],
    'mbappe_ethan': ['ethan mbappé', 'ethan mbappe', 'mbappé'],
    'ueda': ['ayase ueda', 'ueda'],
    'santos_tiago': ['tiago santos', 'santos'],
    'alvarez': ['julián álvarez', 'alvarez', 'álvarez'],
    'griezmann': ['antoine griezmann', 'griezmann'],
    'oblak': ['jan oblak', 'oblak'],
    'kane': ['harry kane', 'kane'],
    'musiala': ['jamal musiala', 'musiala'],
    'neuer': ['manuel neuer', 'neuer'],
    'olise': ['michael olise', 'olise'],
    'luis_diaz': ['luis díaz', 'luis diaz', 'díaz'],
    'moreno': ['gerard moreno', 'moreno'],
    'ayoze': ['ayoze pérez', 'ayoze perez', 'ayoze'],
    'baena': ['álex baena', 'alex baena', 'baena'],
    'hakimi': ['achraf hakimi', 'hakimi'],
    'dembele': ['ousmane dembélé', 'dembele'],
    'barcola': ['bradley barcola', 'barcola'],
    'vitinha': ['vitinha'],
    'marquinhos': ['marquinhos'],
    'nuno_mendes': ['nuno mendes'],
    'yamal': ['lamine yamal', 'yamal'],
    'raphinha': ['raphinha'],
    'lewandowski': ['robert lewandowski', 'lewandowski'],
    'pedri': ['pedri'],
    'gavi': ['gavi'],
    'de_jong': ['frenkie de jong', 'de jong'],
    'balde': ['alejandro balde', 'balde'],
    'kounde': ['jules koundé', 'kounde'],
    'watkins': ['ollie watkins', 'watkins'],
    'martinez': ['emiliano martínez', 'martinez'],
    'rogers': ['morgan rogers', 'rogers'],
    'zulj': ['robert žulj', 'zulj'],
    'usor': ['moses usor', 'usor'],
    'strelec': ['david strelec', 'strelec'],
    'barseghyan': ['tigran barseghyan', 'barseghyan'],
    'weiss': ['vladimír weiss', 'weiss'],
    'marcelli': ['nino marcelli', 'marcelli']
}

with open('data.js', 'r', encoding='utf-8') as f:
    content = f.read()

prefix = 'const UCL_DATA = '
idx_start = content.find(prefix)
svg_marker = 'const UCL_SVGS = '
idx_svg = content.find(svg_marker)

json_text = content[idx_start + len(prefix):idx_svg].strip()
if json_text.endswith(';'):
    json_text = json_text[:-1].strip()

data = json.loads(json_text)

matched_count = 0
for m in data['matches']:
    if 'squadRoster' in m:
        for side in ['home', 'away']:
            if side in m['squadRoster']:
                for player_list in ['injuredPlayers', 'keyPlayers']:
                    for p in m['squadRoster'][side].get(player_list, []):
                        pname = p.get('name', '').lower()
                        # check match
                        found_img = None
                        for img_name, aliases in MAPPING.items():
                            for alias in aliases:
                                if alias in pname:
                                    found_img = f'assets/players/{img_name}.png'
                                    break
                            if found_img:
                                break
                        if found_img:
                            p['image'] = found_img
                            matched_count += 1

print(f"Matched {matched_count} players with face images in squadRoster!")

new_json_str = json.dumps(data, ensure_ascii=False, indent=2)
new_content = content[:idx_start + len(prefix)] + new_json_str + ';\n\n' + content[idx_svg:]

with open('data.js', 'w', encoding='utf-8') as f:
    f.write(new_content)

print("data.js successfully written!")
