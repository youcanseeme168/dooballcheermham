import sys
sys.stdout.reconfigure(encoding='utf-8')
with open('script.js', 'r', encoding='utf-8') as f:
    text = f.read()

pos = text.rfind('})();')
print('Script length:', len(text))
print('End of script.js:')
print(text[pos-300:pos+5])
