import json

with open('data.js', 'r', encoding='utf-8') as f:
    text = f.read()

text = text.split('const UCL_DATA =')[1].strip()
if text.endswith(';'):
    text = text[:-1].strip()

data = json.loads(text)
for m in data['matches']:
    print(f"Match {m['id']}: {m['title']} | {m['homeTeam']['id']} vs {m['awayTeam']['id']}")
