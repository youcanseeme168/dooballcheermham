const fs = require('fs');

// Mock window and document
global.window = { location: { hash: '' } };
global.document = {
  getElementById: () => ({ style: {}, scrollIntoView: () => {} }),
  querySelectorAll: () => []
};

const { UCL_DATA } = require('./data.js');
console.log('Matches count:', UCL_DATA.matches.length);

const m8 = UCL_DATA.matches.find(m => m.id === 8);
console.log('Match 8 Stadium:', m8.stadium.name, '| Image:', m8.stadium.image);
console.log('Match 8 Home Star:', m8.keyDuel.homeStar.name, '| Image:', m8.keyDuel.homeStar.image);
console.log('Match 8 Away Star:', m8.keyDuel.awayStar.name, '| Image:', m8.keyDuel.awayStar.image);
console.log('Match 8 Quick Verdict Pick:', m8.quickVerdict.pick);
console.log('Match 8 Injured players (Home):', m8.squadRoster.home.injuredPlayers.map(p => `${p.name} (img: ${p.image || 'none'})`));
console.log('Match 8 Injured players (Away):', m8.squadRoster.away.injuredPlayers.map(p => `${p.name} (img: ${p.image || 'none'})`));
