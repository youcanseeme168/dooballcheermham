# -*- coding: utf-8 -*-
"""
Integrate Stadium Card, Star Duel Card, Quick Verdict Card, and Sofascore player avatars.
"""

# 1. Update style.css
css_addition = """
/* ==========================================================================
   Stadium Showcase, Star Duel & Quick Verdict Components
   ========================================================================== */

/* Quick Verdict Card */
.quick-verdict-card {
  background: linear-gradient(135deg, rgba(16, 24, 48, 0.95) 0%, rgba(8, 12, 24, 0.98) 100%);
  border: 1px solid rgba(0, 240, 255, 0.25);
  border-radius: var(--radius-lg);
  padding: 1.5rem;
  margin-bottom: 2rem;
  position: relative;
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.4), 0 0 20px rgba(0, 240, 255, 0.08);
}

.quick-verdict-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: linear-gradient(90deg, var(--accent-ucl), var(--accent-gold));
  border-radius: var(--radius-lg) var(--radius-lg) 0 0;
}

.quick-verdict-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1rem;
}

.quick-verdict-item {
  background: rgba(5, 8, 17, 0.65);
  border: 1px solid rgba(255, 255, 255, 0.05);
  border-radius: var(--radius-md);
  padding: 1.1rem;
  display: flex;
  flex-direction: column;
}

.quick-verdict-label {
  font-size: 0.75rem;
  font-weight: 800;
  text-transform: uppercase;
  margin-bottom: 0.5rem;
  display: flex;
  align-items: center;
  gap: 0.4rem;
}

.label-pick { color: var(--accent-ucl); }
.label-key { color: var(--accent-gold); }
.label-trap { color: #f87171; }

.quick-verdict-text {
  font-size: 0.88rem;
  line-height: 1.6;
  color: #e2e8f0;
}

/* Stadium Showcase Card */
.stadium-showcase-card {
  position: relative;
  border-radius: var(--radius-lg);
  overflow: hidden;
  border: 1px solid var(--border-subtle);
  background: var(--bg-card);
  margin-bottom: 2rem;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
}

.stadium-backdrop {
  height: 240px;
  position: relative;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}

.stadium-backdrop::after {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(180deg, rgba(3, 7, 18, 0.1) 0%, rgba(3, 7, 18, 0.75) 60%, rgba(3, 7, 18, 0.98) 100%);
}

.stadium-badge-top {
  position: absolute;
  top: 1rem;
  left: 1rem;
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  background: rgba(3, 7, 18, 0.8);
  backdrop-filter: blur(8px);
  padding: 0.4rem 0.85rem;
  border-radius: var(--radius-full);
  border: 1px solid rgba(255, 255, 255, 0.15);
  font-size: 0.8rem;
  font-weight: 700;
  color: var(--accent-ucl);
}

.stadium-content {
  position: relative;
  z-index: 2;
  padding: 0 1.5rem 1.5rem;
  margin-top: -3.5rem;
}

.stadium-title-row {
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  flex-wrap: wrap;
  gap: 0.75rem;
  margin-bottom: 1rem;
}

.stadium-name-thai {
  font-size: 1.4rem;
  font-weight: 900;
  color: #fff;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  text-shadow: 0 2px 10px rgba(0, 0, 0, 0.8);
}

.stadium-name-en {
  font-size: 0.85rem;
  color: var(--accent-gold);
  font-weight: 600;
  margin-top: 0.2rem;
}

.stadium-location-pill {
  font-size: 0.82rem;
  color: var(--text-muted);
  background: rgba(255, 255, 255, 0.08);
  padding: 0.35rem 0.85rem;
  border-radius: var(--radius-full);
  border: 1px solid rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(4px);
}

.stadium-specs-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 0.85rem;
  margin-bottom: 1rem;
}

.stadium-spec-item {
  background: rgba(5, 8, 17, 0.7);
  border: 1px solid rgba(255, 255, 255, 0.05);
  border-radius: var(--radius-sm);
  padding: 0.85rem 1.1rem;
}

.stadium-spec-label {
  font-size: 0.72rem;
  color: var(--text-dim);
  text-transform: uppercase;
  font-weight: 700;
  margin-bottom: 0.25rem;
  display: flex;
  align-items: center;
  gap: 0.4rem;
}

.stadium-spec-value {
  font-size: 0.95rem;
  font-weight: 700;
  color: #fff;
}

.stadium-atmosphere-box {
  background: rgba(0, 240, 255, 0.04);
  border: 1px solid rgba(0, 240, 255, 0.18);
  border-radius: var(--radius-sm);
  padding: 0.9rem 1.2rem;
  font-size: 0.9rem;
  line-height: 1.65;
  color: #d1d5db;
}

/* Star Duel Matchup Card */
.star-duel-card {
  background: var(--bg-card);
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius-lg);
  padding: 1.5rem;
  margin-bottom: 2rem;
  box-shadow: var(--shadow-card);
}

.star-duel-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1.35rem;
  padding-bottom: 0.85rem;
  border-bottom: 1px solid rgba(255, 255, 255, 0.06);
}

.star-duel-grid {
  display: grid;
  grid-template-columns: 1fr auto 1fr;
  align-items: stretch;
  gap: 1.5rem;
}

.star-player-side {
  background: rgba(5, 8, 17, 0.65);
  border: 1px solid rgba(255, 255, 255, 0.06);
  border-radius: var(--radius-md);
  padding: 1.35rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  position: relative;
  overflow: hidden;
  transition: transform 0.2s ease, border-color 0.2s ease, box-shadow 0.2s ease;
}

.star-player-side:hover {
  transform: translateY(-4px);
  border-color: var(--accent-ucl);
  box-shadow: 0 8px 25px rgba(0, 240, 255, 0.15);
}

.star-photo-wrap {
  width: 96px;
  height: 96px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(0, 240, 255, 0.2) 0%, rgba(10, 16, 30, 0.9) 100%);
  border: 2.5px solid var(--accent-ucl);
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  margin-bottom: 0.9rem;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.6);
}

.star-photo-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transform: scale(1.18) translateY(4px);
}

.star-player-name {
  font-size: 1.15rem;
  font-weight: 800;
  color: #fff;
  margin-bottom: 0.25rem;
}

.star-player-sub {
  font-size: 0.8rem;
  color: var(--accent-gold);
  font-weight: 700;
  margin-bottom: 0.65rem;
}

.star-form-tag {
  font-size: 0.78rem;
  font-weight: 700;
  color: #38bdf8;
  background: rgba(56, 189, 248, 0.1);
  padding: 0.3rem 0.75rem;
  border-radius: var(--radius-full);
  margin-bottom: 0.85rem;
  border: 1px solid rgba(56, 189, 248, 0.25);
}

.star-player-stat {
  font-size: 0.84rem;
  line-height: 1.6;
  color: #cbd5e1;
  background: rgba(0, 0, 0, 0.3);
  padding: 0.75rem 0.95rem;
  border-radius: var(--radius-sm);
  width: 100%;
  flex-grow: 1;
}

.star-player-val {
  font-size: 0.78rem;
  color: var(--text-dim);
  margin-top: 0.75rem;
  font-family: var(--font-mono);
}

.star-duel-center-vs {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 0.65rem;
}

.star-vs-badge {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  background: linear-gradient(135deg, #00f0ff 0%, #3b82f6 100%);
  color: #020817;
  font-weight: 900;
  font-size: 1rem;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 0 18px rgba(0, 240, 255, 0.5);
}

/* Sofascore Real Player Avatar in Injury Board */
.injury-player-avatar-wrap {
  position: relative;
  width: 42px;
  height: 42px;
  border-radius: 50%;
  background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
  border: 2px solid var(--border-light);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.5);
}

.injury-player-photo-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transform: scale(1.15) translateY(2px);
}

.avatar-status-dot {
  position: absolute;
  bottom: 0;
  right: 0;
  width: 11px;
  height: 11px;
  border-radius: 50%;
  border: 2px solid #0f172a;
}

.dot-out {
  background: #f43f5e;
}

.dot-suspended {
  background: #e11d48;
}

.pos-fallback {
  font-weight: 800;
  font-size: 0.75rem;
  color: var(--accent-ucl);
}

/* Mobile Responsive */
@media (max-width: 768px) {
  .stadium-specs-grid {
    grid-template-columns: 1fr;
  }
  .star-duel-grid {
    grid-template-columns: 1fr;
    gap: 1.25rem;
  }
  .star-duel-center-vs {
    flex-direction: row;
    margin: -0.5rem 0;
  }
  .quick-verdict-grid {
    grid-template-columns: 1fr;
  }
  .stadium-backdrop {
    height: 170px;
  }
  .stadium-content {
    margin-top: -2.5rem;
    padding: 0 1rem 1rem;
  }
  .stadium-name-thai {
    font-size: 1.2rem;
  }
}
"""

with open('style.css', 'r', encoding='utf-8') as f:
    style_content = f.read()

if '/* Quick Verdict Card */' not in style_content:
    with open('style.css', 'a', encoding='utf-8') as f:
        f.write('\n' + css_addition)
    print("style.css appended with Stadium, Star Duel, and Verdict styles!")
else:
    print("style.css already has styles!")

# 2. Update script.js with helper functions and match detail injection
with open('script.js', 'r', encoding='utf-8') as f:
    js_content = f.read()

helpers_code = """
  // Render Stadium Showcase Card
  function renderStadiumCard(m) {
    const stad = m.stadium;
    if (!stad || typeof stad === 'string') return '';
    const bgImg = stad.image || `assets/stadiums/match${m.id}.jpg`;
    return `
      <div class="stadium-showcase-card">
        <div class="stadium-backdrop" style="background-image: url('${bgImg}');">
          <div class="stadium-badge-top">
            <i class="ri-map-pin-2-fill"></i> ${stad.countryFlag || '🏟️'} ${stad.city}, ${stad.country}
          </div>
        </div>
        <div class="stadium-content">
          <div class="stadium-title-row">
            <div>
              <div class="stadium-name-thai"><i class="ri-government-line" style="color:var(--accent-gold);"></i> ${stad.thaiName}</div>
              <div class="stadium-name-en">${stad.name}</div>
            </div>
            <div class="stadium-location-pill">
              <i class="ri-user-voice-line"></i> ความจุ ${stad.capacity}
            </div>
          </div>
          <div class="stadium-specs-grid">
            <div class="stadium-spec-item">
              <div class="stadium-spec-label"><i class="ri-football-line"></i> พื้นผิวสนาม</div>
              <div class="stadium-spec-value">${stad.surface}</div>
            </div>
            <div class="stadium-spec-item">
              <div class="stadium-spec-label"><i class="ri-temp-cold-line"></i> สภาพอากาศ</div>
              <div class="stadium-spec-value">${stad.climate}</div>
            </div>
            <div class="stadium-spec-item">
              <div class="stadium-spec-label"><i class="ri-sound-module-line"></i> ระดับเสียงเชียร์</div>
              <div class="stadium-spec-value" style="font-size:0.9rem;color:var(--accent-gold);">ดังกึกก้อง (High Pressure)</div>
            </div>
          </div>
          <div class="stadium-atmosphere-box">
            <strong style="color:var(--accent-gold);"><i class="ri-fire-line"></i> บรรยากาศ & จุดที่ต้องระวัง:</strong> ${stad.atmosphere}
          </div>
        </div>
      </div>
    `;
  }

  // Render Star Duel Matchup Card
  function renderStarDuelCard(m) {
    const duel = m.keyDuel;
    if (!duel) return '';
    const h = duel.homeStar;
    const a = duel.awayStar;
    return `
      <div class="star-duel-card">
        <div class="star-duel-header">
          <div class="pillar-title" style="font-size:1.05rem;display:flex;align-items:center;gap:0.5rem;">
            <i class="ri-flashlight-fill" style="color:var(--accent-gold);"></i> การ์ดดวลแข้งคีย์แมนฟอร์มฮอต (Star vs Star Matchup)
          </div>
          <span class="badge badge-ucl">คีย์แมนตัดสินเกม</span>
        </div>
        <div class="star-duel-grid">
          <!-- Home Star -->
          <div class="star-player-side">
            <div class="star-photo-wrap">
              <img src="${h.image}" class="star-photo-img" alt="${h.name}" onerror="this.onerror=null; this.src='assets/logos/${m.homeTeam.id}.png';">
            </div>
            <div class="star-player-name">${h.thaiName}</div>
            <div class="star-player-sub">${h.name} (#${h.number || ''} • ${h.pos})</div>
            <div class="star-form-tag">${h.formTag}</div>
            <div class="star-player-stat">${h.stat}</div>
            <div class="star-player-val">มูลค่าประเมิน: <strong style="color:#fff;">${h.value}</strong></div>
          </div>

          <!-- Center VS -->
          <div class="star-duel-center-vs">
            <div class="star-vs-badge">VS</div>
            <span style="font-size:0.75rem;color:var(--text-dim);font-weight:700;">DUEL</span>
          </div>

          <!-- Away Star -->
          <div class="star-player-side">
            <div class="star-photo-wrap">
              <img src="${a.image}" class="star-photo-img" alt="${a.name}" onerror="this.onerror=null; this.src='assets/logos/${m.awayTeam.id}.png';">
            </div>
            <div class="star-player-name">${a.thaiName}</div>
            <div class="star-player-sub">${a.name} (#${a.number || ''} • ${a.pos})</div>
            <div class="star-form-tag">${a.formTag}</div>
            <div class="star-player-stat">${a.stat}</div>
            <div class="star-player-val">มูลค่าประเมิน: <strong style="color:#fff;">${a.value}</strong></div>
          </div>
        </div>
      </div>
    `;
  }

  // Render 1-Minute Quick Verdict Card
  function renderQuickVerdictCard(m) {
    const v = m.quickVerdict;
    if (!v) return '';
    return `
      <div class="quick-verdict-card">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;flex-wrap:wrap;gap:0.5rem;">
          <div style="font-size:1.05rem;font-weight:900;color:#fff;display:flex;align-items:center;gap:0.5rem;">
            <i class="ri-timer-flash-line" style="color:var(--accent-ucl);font-size:1.25rem;"></i> บทสรุปย่อ 1 นาที (Quick Verdict & Key Factors)
          </div>
          <span class="badge badge-gold" style="font-size:0.75rem;"><i class="ri-shield-check-line"></i> สรุปชี้ชัด</span>
        </div>
        <div class="quick-verdict-grid">
          <div class="quick-verdict-item">
            <div class="quick-verdict-label label-pick"><i class="ri-focus-3-line"></i> 1. ตลาดน่าเล่น & สกอร์คาดการณ์</div>
            <div class="quick-verdict-text">
              <strong style="color:var(--accent-ucl);font-size:0.95rem;display:block;margin-bottom:0.35rem;">${v.pick}</strong>
              <span style="color:var(--accent-gold);font-weight:700;">สกอร์คาดการณ์: ${v.score}</span>
            </div>
          </div>
          <div class="quick-verdict-item">
            <div class="quick-verdict-label label-key"><i class="ri-key-2-line"></i> 2. จุดตัดสำคัญ / แท็กติกชี้ขาด</div>
            <div class="quick-verdict-text">${v.keyPoint}</div>
          </div>
          <div class="quick-verdict-item">
            <div class="quick-verdict-label label-trap"><i class="ri-alert-line"></i> 3. กับดักราคา & ข้อควรระวัง</div>
            <div class="quick-verdict-text">${v.trapAlert}</div>
          </div>
        </div>
      </div>
    `;
  }
"""

if 'function renderStadiumCard' not in js_content:
    # insert before renderMatchDetail
    idx_render_detail = js_content.find('function renderMatchDetail(matchId) {')
    if idx_render_detail != -1:
        js_content = js_content[:idx_render_detail] + helpers_code + '\n' + js_content[idx_render_detail:]
        print("Inserted helper functions into script.js!")
    else:
        print("Error: Could not find renderMatchDetail in script.js")

# In renderMatchDetail, inject Quick Verdict, Stadium, and Star Duel
old_detail_hero = """          <div class="detail-hero-meta-grid">
            <div class="detail-meta-item">
              <strong>สนามแข่งขัน</strong>
              <span>${m.stadium}</span>
            </div>
            <div class="detail-meta-item">
              <strong>โปรแกรมและเวลาพัก</strong>
              <span>${m.scheduleAndRest}</span>
            </div>
            <div class="detail-meta-item">
              <strong>สภาพแวดล้อมสนาม</strong>
              <span>${m.pitchAndWeather}</span>
            </div>
          </div>
        </div>

        <!-- Pillar Navigation Tabs -->"""

new_detail_hero = """          <div class="detail-hero-meta-grid">
            <div class="detail-meta-item">
              <strong>สนามแข่งขัน</strong>
              <span>${typeof m.stadium === 'object' ? m.stadium.thaiName + ' (' + m.stadium.city + ')' : m.stadium}</span>
            </div>
            <div class="detail-meta-item">
              <strong>โปรแกรมและเวลาพัก</strong>
              <span>${m.scheduleAndRest}</span>
            </div>
            <div class="detail-meta-item">
              <strong>สภาพแวดล้อมสนาม</strong>
              <span>${m.pitchAndWeather}</span>
            </div>
          </div>
        </div>

        <!-- 1-Minute Quick Verdict Card -->
        ${renderQuickVerdictCard(m)}

        <!-- Stadium Showcase Card -->
        ${renderStadiumCard(m)}

        <!-- Star vs Star Duel Card -->
        ${renderStarDuelCard(m)}

        <!-- Pillar Navigation Tabs -->"""

if old_detail_hero in js_content:
    js_content = js_content.replace(old_detail_hero, new_detail_hero)
    print("Injected Quick Verdict, Stadium, and Star Duel into renderMatchDetail!")
else:
    print("Warning: old_detail_hero not found exactly in script.js")

with open('script.js', 'w', encoding='utf-8') as f:
    f.write(js_content)

print("script.js updated successfully!")
