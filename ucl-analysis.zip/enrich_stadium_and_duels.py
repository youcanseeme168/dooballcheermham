# -*- coding: utf-8 -*-
"""
Inject Stadium, Key Star Duels, and Quick Verdicts into data.js.
Ensures local player headshots and stadium images are referenced.
"""
import json
import re

METADATA = {
    1: {
        "stadium": {
            "name": "RAMS Park (Ali Sami Yen)",
            "thaiName": "แรมส์ พาร์ค (อาลี ซามี เยน)",
            "city": "Istanbul",
            "country": "Turkey",
            "countryFlag": "🇹🇷",
            "capacity": "52,280 ที่นั่ง",
            "surface": "หญ้าจริง (Natural Grass)",
            "climate": "อากาศเย็น 14°C ลมกระโชก",
            "atmosphere": "สังเวียน 'Welcome to Hell' อันเลื่องชื่อ เสียงเชียร์ระดับทะลุ 130 เดซิเบล กดดันคู่แข่งจนตั้งกระบวนไม่ติด",
            "image": "assets/stadiums/match1.jpg"
        },
        "keyDuel": {
            "homeStar": {
                "name": "Victor Osimhen",
                "thaiName": "วิกเตอร์ โอซิมเฮน",
                "number": 45,
                "pos": "FW / กองหน้าตัวเป้า",
                "image": "assets/players/osimhen.png",
                "formTag": "🔥 ดาวยิงฟอร์มฮอตระดับโลก",
                "stat": "ซัดไปแล้ว 5 ประตูในลีก และมีส่วนร่วมกับประตูในยุโรปอย่างต่อเนื่อง พลังกระโดดและสปีดทำลายล้าง",
                "value": "75M€"
            },
            "awayStar": {
                "name": "Ermedin Demirović",
                "thaiName": "เอร์เมดิน เดมิโรวิช",
                "number": 9,
                "pos": "FW / หัวหอกม้าขาว",
                "image": "assets/players/demirovic.png",
                "formTag": "⚽ จอมสังหารฟุตบอลยุโรป",
                "stat": "ทำไปแล้ว 4 ประตูใน UCL ซีซั่นนี้ จบสกอร์เฉียบคมในกรอบเขตโทษ เรตติ้งเฉลี่ยสูงถึง 7.6",
                "value": "28M€"
            }
        },
        "quickVerdict": {
            "pick": "สกอร์สูง Over 2.5 (@ 1.43) และ ทั้งสองทีมยิงได้ BTTS (@ 1.38)",
            "score": "2–1 หรือ 2–2",
            "keyPoint": "กาลาตาซารายในบ้านเปิดเกมรุกแลกหมัดแหลก แต่หลังมีรอยรั่ว ขณะที่สตุ๊ตการ์ทขาด อังเจโล่ สติลเลอร์ คุมกลาง ทำให้ตัดเกมยากแต่เกมรุกยังจัดจ้าน",
            "trapAlert": "ราคาต่อ กาลาตาซาราย ค่อนข้างตึง ม้าขาวสตุ๊ตการ์ทยังมีเกมโต้กลับที่อันตราย การเล่นหน้าสกอร์สูงชัวร์กว่า"
        }
    },
    2: {
        "stadium": {
            "name": "Volksparkstadion (สนามกลาง)",
            "thaiName": "โฟล์กสพาร์คสตาดิโอน (สนามกลาง ฮัมบูร์ก)",
            "city": "Hamburg",
            "country": "Germany (สนามกลาง)",
            "countryFlag": "🇩🇪",
            "capacity": "57,000 ที่นั่ง",
            "surface": "หญ้าจริง (Natural Grass)",
            "climate": "อากาศหนาวจัด 7°C สนามกลาง",
            "atmosphere": "ชัคตาร์ใช้รังเหย้าชั่วคราวในเยอรมนี ทำให้เสียเปรียบเรื่องบรรยากาศกองเชียร์เจ้าบ้านแท้จริง",
            "image": "assets/stadiums/match2.jpg"
        },
        "keyDuel": {
            "homeStar": {
                "name": "Georgiy Sudakov",
                "thaiName": "จอร์จี้ ซูดาคอฟ",
                "number": 10,
                "pos": "MF / จอมทัพยูเครน",
                "image": "assets/players/sudakov.png",
                "formTag": "🧠 มันสมองของชัคตาร์",
                "stat": "สร้างสรรค์โอกาสยิงเฉลี่ย 3.2 ครั้งต่อเกม จ่ายบอลคิลเลอร์พาสแม่นยำ เรตติ้ง 7.8",
                "value": "35M€"
            },
            "awayStar": {
                "name": "Viktor Gyökeres",
                "thaiName": "วิกเตอร์ เกียวเคเรส",
                "number": 9,
                "pos": "FW / กองหน้าเครื่องจักรสังหาร",
                "image": "assets/players/gyokeres.png",
                "formTag": "🤖 เครื่องจักรถล่มประตู",
                "stat": "สถิติยิงถล่มทลายในลีกและยุโรป สปีดและความแข็งแกร่งทำลายแนวรับคู่แข่งขาดวิ่น",
                "value": "70M€"
            }
        },
        "quickVerdict": {
            "pick": "สปอร์ติ้ง ลิสบอน ชนะ (@ 1.97) หรือ Double Chance X2 (@ 1.32)",
            "score": "1–2 หรือ 0–1",
            "keyPoint": "ชัคตาร์เตะสนามกลางขาดแรงเชียร์ ขณะที่ สปอร์ติ้ง ฟอร์มดุจัดจ้าน เกียวเคเรส ค้ำหน้าพร้อมป่วนทุกจังหวะ",
            "trapAlert": "ราคาสปอร์ติ้งเกือบ 2.00 คุ้มค่าที่สุดสำหรับทีมเยือนที่มีคุณภาพเกมรุกเหนือชั้นกว่าชัดเจน"
        }
    },
    3: {
        "stadium": {
            "name": "De Kuip (Stadion Feijenoord)",
            "thaiName": "เดอ ไกป์ (เฟเยนูร์ด สเตเดี้ยม)",
            "city": "Rotterdam",
            "country": "Netherlands",
            "countryFlag": "🇳🇱",
            "capacity": "51,117 ที่นั่ง",
            "surface": "หญ้าจริง (Natural Grass)",
            "climate": "หนาวชื้น 9°C ลมทะเลเหนือ",
            "atmosphere": "อ่างกระทะเหล็กเดอไกป์ นรกของทีมเยือน เสียงเชียร์เร้าอารมณ์สั่นสะเทือนอัฒจันทร์",
            "image": "assets/stadiums/match3.jpg"
        },
        "keyDuel": {
            "homeStar": {
                "name": "Santiago Giménez",
                "thaiName": "ซานติอาโก้ คิเมเนซ",
                "number": 29,
                "pos": "FW / ดาวยิงเม็กซิกัน",
                "image": "assets/players/gimenez.png",
                "formTag": "🎯 จอมสังหารหน้าปากประตู",
                "stat": "ยิงไป 6 ประตูจาก 8 นัดหลังสุด ปฏิกิริยาในกรอบเขตโทษรวดเร็ว หาช่องยิงได้ทุกมุม",
                "value": "40M€"
            },
            "awayStar": {
                "name": "Lautaro Martínez",
                "thaiName": "เลาตาโร่ มาร์ติเนซ",
                "number": 10,
                "pos": "FW / กัปตันงูใหญ่",
                "image": "assets/players/lautaro.png",
                "formTag": "🐂 เอล โตโร่ ดาวยิงเวิลด์คลาส",
                "stat": "ความเฉียบคมเกมยุโรประดับหัวแถว ครองบอลเหนียวแน่นและประสานงานกับ ตูราม อันตรายสุดๆ",
                "value": "110M€"
            }
        },
        "quickVerdict": {
            "pick": "สกอร์สูง Over 2.5 (@ 1.41) และ ทั้งสองทีมยิงได้ BTTS (@ 1.43)",
            "score": "1–2",
            "keyPoint": "ทั้งคู่ขาดกองหลังตัวหลักหลายคน เฟเยนูร์ดในบ้านไม่เคยกลัวใคร ส่วนอินเตอร์เกมสวนกลับแม่นยำ โอกาสแลกกันยิงสูงมาก",
            "trapAlert": "ราคาต่อของอินเตอร์ไม่ควรเสี่ยงวาง เพราะเดอไกป์เล่นยากมาก ให้หันมาจับตลาดสกอร์สูงที่มั่นคงกว่า"
        }
    },
    4: {
        "stadium": {
            "name": "Aspmyra Stadion",
            "thaiName": "อัสป์มีรา สตาดิโอน (รังเหย้าขั้วโลกเหนือ)",
            "city": "Bodø",
            "country": "Norway",
            "countryFlag": "🇳🇴",
            "capacity": "8,270 ที่นั่ง",
            "surface": "หญ้าเทียม (Artificial Turf)",
            "climate": "หนาวจัดใกล้ 0°C ลมพายุขั้วโลก",
            "atmosphere": "สนามหญ้าเทียมขั้วโลกเหนือที่สร้างฝันร้ายให้ทีมยักษ์ใหญ่ยุโรปมานักต่อนัก บอลพุ่งเร็วและอากาศยะเยือก",
            "image": "assets/stadiums/match4.jpg"
        },
        "keyDuel": {
            "homeStar": {
                "name": "Patrick Berg",
                "thaiName": "พาทริก เบิร์ก",
                "number": 7,
                "pos": "MF / กัปตันโบโดฯ",
                "image": "assets/players/berg.png",
                "formTag": "👑 หัวใจแดนกลางขั้วโลกเหนือ",
                "stat": "วิ่งคุมพื้นที่ทั่วสนาม วางบอลยาวและยิงไกลนอกกรอบได้แม่นยำ คุ้นชินกับสนามหญ้าเทียมเป็นที่สุด",
                "value": "5M€"
            },
            "awayStar": {
                "name": "Jonathan David",
                "thaiName": "โจนาธาน เดวิด",
                "number": 9,
                "pos": "FW / จรวดทางเรียบแคนาดา",
                "image": "assets/players/david.png",
                "formTag": "⚡ ดาวยิงสปีดจัดจ้าน",
                "stat": "ดาวซัลโวของลีลล์ สปีดฉีกแผงหลังและจบสกอร์เยือกเย็น ยิงในลีกเอิงสม่ำเสมอ",
                "value": "50M€"
            }
        },
        "quickVerdict": {
            "pick": "โบโด/กลิมท์ ชนะ (1) (@ 1.92) หรือ โบโด ยิงเกิน 1.5 ลูก",
            "score": "2–1 หรือ 3–1",
            "keyPoint": "โบโดชนะเกมเหย้ายุโรป 6 นัดรวด ชินหญ้าเทียมและอากาศขั้วโลก ส่วนลีลล์แพ้ยุโรป 5 นัดติดและขาดตัวหลักเพียบ",
            "trapAlert": "ลีลล์มีปัญหาเรื่องสภาพความฟิตและฟอร์มครึ่งหลังที่เสียประตูเป็นประจำ ราคา 1.92 ของโบโดคือความคุ้มค่าระดับ 5 ดาว"
        }
    },
    5: {
        "stadium": {
            "name": "Riyadh Air Metropolitano",
            "thaiName": "ริยาด แอร์ เมโทรโปลิตาโน่",
            "city": "Madrid",
            "country": "Spain",
            "countryFlag": "🇪🇸",
            "capacity": "70,460 ที่นั่ง",
            "surface": "หญ้าจริงไฮบริด (Hybrid Grass)",
            "climate": "อากาศเย็นสบาย 15°C",
            "atmosphere": "ป้อมปราการหินของ ดิเอโก้ ซิเมโอเน่ แฟนบอลตราหมีส่งเสียงกระหึ่ม กดดันคู่แข่งและผู้ตัดสินตลอด 90 นาที",
            "image": "assets/stadiums/match5.jpg"
        },
        "keyDuel": {
            "homeStar": {
                "name": "Julián Álvarez",
                "thaiName": "ฮูเลียน อัลวาเรซ",
                "number": 19,
                "pos": "FW / สไปเดอร์แมนตราหมี",
                "image": "assets/players/alvarez.png",
                "formTag": "🕷️ กองหน้าพลังเพรสซิ่งสูง",
                "stat": "วิ่งบดแนวรับคู่แข่งไม่มีหยุด ประสานงานกับ กรีซมันน์ ได้อย่างลงตัว ยิงและแอสซิสต์ในบ้านอย่างดุ",
                "value": "90M€"
            },
            "awayStar": {
                "name": "Harry Kane",
                "thaiName": "แฮร์รี่ เคน",
                "number": 9,
                "pos": "FW / ดาวยิงกัปตันสิงโตคำราม",
                "image": "assets/players/kane.png",
                "formTag": "🎯 เครื่องจักรถล่มตาข่ายบาเยิร์น",
                "stat": "ค่าเฉลี่ยทำประตูใน UCL เกิน 1.0 ลูกต่อนัด สถิติจุดโทษ 100% เล่นลูกกลางอากาศและดึงตัวประกบยอดเยี่ยม",
                "value": "100M€"
            }
        },
        "quickVerdict": {
            "pick": "ทั้งสองทีมยิงได้ BTTS - Yes (@ 1.36) หรือ รอง แอตฯ มาดริด 1X",
            "score": "2–1 หรือ 1–1",
            "keyPoint": "แอตฯ มาดริดในบ้าน UCL ชนะ 10 จาก 12 นัด ยิงได้ 20 นัดรวด บาเยิร์นยิงในยุโรป 24 นัดรวดแต่ขาด นอยเออร์ และแนวรับเปื่อย",
            "trapAlert": "บาเยิร์นเป็นต่อที่ราคา 2.04 ทั้งที่สะดุดเสมอมา 2 นัดติด ระวังเสร็จแท็กติกเคี่ยวระดับมาสเตอร์ของ ซิเมโอเน่"
        }
    },
    6: {
        "stadium": {
            "name": "Estadio de la Cerámica",
            "thaiName": "เอสตาดิโอ เด ลา เซรามิก้า",
            "city": "Villarreal",
            "country": "Spain",
            "countryFlag": "🇪🇸",
            "capacity": "23,000 ที่นั่ง",
            "surface": "หญ้าจริง (Natural Grass)",
            "climate": "อากาศเย็นสบายเมดิเตอร์เรเนียน 16°C",
            "atmosphere": "อัฒจันทร์สีเหลืองอร่ามตั้งประชิดขอบสนาม สร้างความอึดอัดให้ทีมเยือน แต่เป็นรังที่เปิดแลกหมัดสนุก",
            "image": "assets/stadiums/match6.jpg"
        },
        "keyDuel": {
            "homeStar": {
                "name": "Gerard Moreno",
                "thaiName": "เคราร์ด โมเรโน่",
                "number": 7,
                "pos": "FW / มันสมองเรือดำน้ำสีเหลือง",
                "image": "assets/players/moreno.png",
                "formTag": "🏹 กองหน้าสายเทคนิคชั้นครู",
                "stat": "พักบอล เชื่อมเกม และจ่ายบอลคิลเลอร์พาสได้อันตราย สถิติยิงในบ้านสม่ำเสมอที่สุดของทีม",
                "value": "15M€"
            },
            "awayStar": {
                "name": "Achraf Hakimi",
                "thaiName": "อัชราฟ ฮาคิมี่",
                "number": 2,
                "pos": "DF / แบ็กขวาจรวดทางเรียบ",
                "image": "assets/players/hakimi.png",
                "formTag": "⚡ ฟูลแบ็กพลังเกมรุกทะลุขีดจำกัด",
                "stat": "มีส่วนร่วมกับประตูของเปแอสเชอย่างสม่ำเสมอ เติมเกมรุกสปีดจัดจ้านและยิงไกลนอกกรอบได้เฉียบคม",
                "value": "60M€"
            }
        },
        "quickVerdict": {
            "pick": "เปแอสเช ชนะ (@ 1.65) และ ทั้งสองทีมยิงได้ BTTS (@ 1.43)",
            "score": "1–3 หรือ 1–2",
            "keyPoint": "เปแอสเชชนะรวด 9 นัดทุกรายการ ยิงไป 30 ประตู เรตติ้งทีมสูงสุดในยุโรป (8.09) ส่วนบียาร์เรอัลสถิติ 12 จาก 14 นัดเหย้าเกิด BTTS",
            "trapAlert": "บียาร์เรอัลเปิดหน้าแลกในบ้านมีสิทธิ์โดนเปแอสเชสวนกลับยับเยิน ราคาเปแอสเช 1.65 น่าเชื่อถือที่สุดในค่ำคืนนี้"
        }
    },
    7: {
        "stadium": {
            "name": "Estadi Olímpic Lluís Companys / Camp Nou",
            "thaiName": "เอสตาดิ โอลิมปิก ยูอิส กอมปานีส์ (มองต์คูอิก)",
            "city": "Barcelona",
            "country": "Spain",
            "countryFlag": "🇪🇸",
            "capacity": "54,367 ที่นั่ง",
            "surface": "หญ้าจริง (Natural Grass)",
            "climate": "อากาศเย็นสดชื่น 15°C",
            "atmosphere": "ยอดเขามองต์คูอิก แฟนบอลบาร์ซ่าเชียร์สไตล์ต่อบอลติกิตาก้า บรรยากาศเปิดกว้าง เกมรุกไหลลื่น",
            "image": "assets/stadiums/match7.jpg"
        },
        "keyDuel": {
            "homeStar": {
                "name": "Lamine Yamal",
                "thaiName": "ลามีน ยามาล",
                "number": 19,
                "pos": "FW / วันเดอร์คิดเบอร์ 1 ของโลก",
                "image": "assets/players/yamal.png",
                "formTag": "🌟 มหัศจรรย์แข้งทองบาร์เซโลน่า",
                "stat": "เลี้ยงกินตัวสำเร็จสูงสุดในยุโรป สร้างโอกาสจะแจ้ง (Big Chances) เฉลี่ย 1.8 ครั้งต่อเกม",
                "value": "150M€"
            },
            "awayStar": {
                "name": "Ollie Watkins",
                "thaiName": "โอลลี่ วัตกิ้นส์",
                "number": 11,
                "pos": "FW / ดาวยิงตัวฉกาจสิงห์ผงาด",
                "image": "assets/players/watkins.png",
                "formTag": "🏃 กองหน้าจอมฉีกแนวรับ",
                "stat": "สปีดกระชากหลังขาด ยิงใน UCL ซีซั่นนี้ต่อเนื่อง พาทีมคว้าชัย 3 นัดรวดในยุโรป",
                "value": "65M€"
            }
        },
        "quickVerdict": {
            "pick": "ทั้งสองทีมยิงได้ BTTS - Yes (@ 1.50) หรือ รอง แอสตัน วิลล่า (+1.75)",
            "score": "3–1 หรือ 2–1",
            "keyPoint": "บาร์ซ่าไม่คลีนชีตใน UCL มา 18 นัดติด ขาดกองหลังตัวจริง 4 คน ส่วนวิลล่าชนะรวด 3 นัดใน UCL ยิงไป 12 ลูก",
            "trapAlert": "ราคาบาร์ซ่าต่อขาดลอย (1.23–1.28) ต่ำเกินความคุ้มค่า ไม่น่าเสี่ยงวางฝั่งเจ้าบ้าน ให้เน้นวางสกอร์ยิงทั้งสองฝั่ง"
        }
    },
    8: {
        "stadium": {
            "name": "Old Trafford (The Theatre of Dreams)",
            "thaiName": "โอลด์ แทรฟฟอร์ด (โรงละครแห่งความฝัน)",
            "city": "Manchester",
            "country": "England",
            "countryFlag": "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
            "capacity": "74,310 ที่นั่ง",
            "surface": "หญ้าจริงไฮบริด (Desso GrassMaster)",
            "climate": "หนาวชื้น 8°C ฝนตกพรำตามสไตล์อังกฤษ",
            "atmosphere": "โรงละครแห่งความฝัน ความจุสูงสุดบนเกาะอังกฤษ แม้ฟอร์มลีกวิกฤตแต่สถิติเกมยุโรปในบ้านชนะ 7 นัดรวด",
            "image": "assets/stadiums/match8.jpg"
        },
        "keyDuel": {
            "homeStar": {
                "name": "Bruno Fernandes",
                "thaiName": "บรูโน่ แฟร์นันเดส",
                "number": 8,
                "pos": "MF / กัปตันทีมปีศาจแดง",
                "image": "assets/players/bruno.png",
                "formTag": "🔥 คีย์แมนผู้แบกความหวังทั้งทีม",
                "stat": "มีส่วนร่วม 5 ประตูจาก 2 นัดที่พบ Roma ในยุโรป (ยิง 2 แอสซิสต์ 3) และ 6 จาก 8 ประตูหลังสุดใน UCL เกิดขึ้นในครึ่งแรก",
                "value": "65M€"
            },
            "awayStar": {
                "name": "Donyell Malen",
                "thaiName": "ดอนเยลล์ มาเลน",
                "number": 14,
                "pos": "FW / ดาวยิงฟอร์มฮอตหมาป่าโรม่า",
                "image": "assets/players/malen.png",
                "formTag": "⚡ แนวรุกท็อปฟอร์มสุดขีด",
                "stat": "มีส่วนร่วมไปแล้วถึง 5 ประตูใน UCL ซีซั่นนี้ (ยิง 3 แอสซิสต์ 2) โดยทั้ง 3 ประตูเกิดขึ้นในช่วงนาที 50–60 ทั้งหมด",
                "value": "40M€"
            }
        },
        "quickVerdict": {
            "pick": "รอง AS Roma (X2 / +0.25) (@ 1.65) หรือ ทั้งสองทีมยิงได้ BTTS (@ 1.50)",
            "score": "1–2 หรือ 2–2",
            "keyPoint": "แมนฯ ยูไนเต็ด วิกฤตหนักไม่ชนะใคร 9 นัดติดต่อกัน รั้งอันดับ 17 พรีเมียร์ลีก ขาด โยโร่, อูการ์เต้, เซสโก้ ส่วนโรม่าไร้พ่าย 17 นัดติดในลีก",
            "trapAlert": "ราคาผีแดงเป็นต่อที่ 2.30 เป็นกับดักชื่อเสียง อย่าหลงเชื่อทีมใหญ่ที่กำลังวิกฤต หันมารองโรม่าปลอดภัยกว่ามาก"
        }
    },
    9: {
        "stadium": {
            "name": "Raiffeisen Arena",
            "thaiName": "ไรฟ์ไฟเซิน อารีน่า (ลินซ์)",
            "city": "Linz",
            "country": "Austria",
            "countryFlag": "🇦🇹",
            "capacity": "19,080 ที่นั่ง",
            "surface": "หญ้าจริง (Natural Grass)",
            "climate": "อากาศหนาวจัด 6°C",
            "atmosphere": "สนามใหม่ของ LASK แฟนบอลอยู่ติดสนาม บรรยากาศเข้มข้น เร้าใจ สร้างความได้เปรียบให้เจ้าถิ่นชัดเจน",
            "image": "assets/stadiums/match9.jpg"
        },
        "keyDuel": {
            "homeStar": {
                "name": "Robert Žulj",
                "thaiName": "โรเบิร์ต ซุลจ์",
                "number": 10,
                "pos": "MF / เพลย์เมกเกอร์มันสมอง",
                "image": "assets/players/zulj.png",
                "formTag": "🎩 จอมทัพผู้คุมจังหวะ LASK",
                "stat": "เรตติ้งเฉลี่ย 7.5 คุมเกมและสอดเข้ามายิงประตูได้แม่นยำ เป็นหัวใจในเกมรุกของทีมอย่างแท้จริง",
                "value": "3M€"
            },
            "awayStar": {
                "name": "David Strelec",
                "thaiName": "ดาวิด สเตรเล็ค",
                "number": 13,
                "pos": "FW / ดาวยิงสโลวาน",
                "image": "assets/players/strelec.png",
                "formTag": "🎯 กองหน้าตัวความหวังเดียว",
                "stat": "ดาวซัลโวของทีมในลีก สปีดและจังหวะฉกฉวยโอกาสในกรอบเขตโทษอันตราย",
                "value": "4M€"
            }
        },
        "quickVerdict": {
            "pick": "LASK ชนะ (1) (@ 1.50) หรือ สกอร์สูง Over 2.5 (@ 1.44)",
            "score": "3–0 หรือ 3–1",
            "keyPoint": "สโลวาน บราติสลาวา เสียไปแล้วถึง 13 ประตูจาก 3 นัดแรกใน UCL เกมรับรั่วที่สุดในทัวร์นาเมนต์ ขณะที่ LASK เพิ่งบุกชนะสปอร์ติ้งมาได้",
            "trapAlert": "สโลวานเล่นเกมเยือนยุโรปต้านไม่เคยไหว LASK เล่นในบ้านลุ้นยิงขาดเกิน 2 ลูกได้สบาย"
        }
    }
}

def update_data_js():
    with open('data.js', 'r', encoding='utf-8') as f:
        content = f.read()

    # Find UCL_DATA object
    prefix = 'const UCL_DATA = '
    idx_start = content.find(prefix)
    if idx_start == -1:
        print("Could not find UCL_DATA")
        return

    json_start = idx_start + len(prefix)
    # find where UCL_DATA ends (before const UCL_SVGS)
    svg_marker = 'const UCL_SVGS = '
    idx_svg = content.find(svg_marker)
    if idx_svg == -1:
        print("Could not find UCL_SVGS")
        return

    # find the semicolon before svg_marker
    json_text = content[json_start:idx_svg].strip()
    if json_text.endswith(';'):
        json_text = json_text[:-1].strip()

    data = json.loads(json_text)

    # Update each match
    for m in data['matches']:
        mid = m['id']
        if mid in METADATA:
            m['stadium'] = METADATA[mid]['stadium']
            m['keyDuel'] = METADATA[mid]['keyDuel']
            m['quickVerdict'] = METADATA[mid]['quickVerdict']

    # Update player image links in rosters if present
    player_img_map = {
        'Victor Osimhen': 'assets/players/osimhen.png',
        'Ermedin Demirović': 'assets/players/demirovic.png',
        'Angelo Stiller': 'assets/players/stiller.png',
        'Georgiy Sudakov': 'assets/players/sudakov.png',
        'Viktor Gyökeres': 'assets/players/gyokeres.png',
        'Santiago Giménez': 'assets/players/gimenez.png',
        'Quinten Timber': 'assets/players/timber.png',
        'Lautaro Martínez': 'assets/players/lautaro.png',
        'Patrick Berg': 'assets/players/berg.png',
        'Jonathan David': 'assets/players/david.png',
        'Julián Álvarez': 'assets/players/alvarez.png',
        'Harry Kane': 'assets/players/kane.png',
        'Manuel Neuer': 'assets/players/neuer.png',
        'Gerard Moreno': 'assets/players/moreno.png',
        'Achraf Hakimi': 'assets/players/hakimi.png',
        'Lamine Yamal': 'assets/players/yamal.png',
        'Ollie Watkins': 'assets/players/watkins.png',
        'Bruno Fernandes': 'assets/players/bruno.png',
        'Donyell Malen': 'assets/players/malen.png',
        'Paulo Dybala': 'assets/players/dybala.png',
        'Leny Yoro': 'assets/players/yoro.png',
        'Manuel Ugarte': 'assets/players/ugarte.png',
        'Benjamin Šeško': 'assets/players/sesko.png',
        'Robert Žulj': 'assets/players/zulj.png',
        'David Strelec': 'assets/players/strelec.png',
    }

    for m in data['matches']:
        if 'roster' in m:
            for side in ['home', 'away']:
                if side in m['roster']:
                    for kp in m['roster'][side].get('keyPlayers', []):
                        pname = kp.get('name', '')
                        for k, v in player_img_map.items():
                            if k.lower() in pname.lower():
                                kp['image'] = v
                    for ip in m['roster'][side].get('injuredPlayers', []):
                        pname = ip.get('name', '')
                        for k, v in player_img_map.items():
                            if k.lower() in pname.lower():
                                ip['image'] = v

    new_json_str = json.dumps(data, ensure_ascii=False, indent=2)
    new_content = content[:json_start] + new_json_str + ';\n\n' + content[idx_svg:]

    with open('data.js', 'w', encoding='utf-8') as f:
        f.write(new_content)

    print("data.js successfully updated with Stadiums, Duels, and Verdicts!")

if __name__ == '__main__':
    update_data_js()
