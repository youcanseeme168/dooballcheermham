# -*- coding: utf-8 -*-
import sys
import json

sys.stdout.reconfigure(encoding='utf-8')
with open('data.js', 'r', encoding='utf-8') as f:
    text = f.read()

data_start = text.find('const UCL_DATA = ') + len('const UCL_DATA = ')
data_end = text.find('const UCL_SVGS = ')
raw_json = text[data_start:data_end].strip()
if raw_json.endswith(';'):
    raw_json = raw_json[:-1]

data = json.loads(raw_json)

print('Total matches:', len(data['matches']))
for m in data['matches']:
    sr = m.get('squadRoster', {})
    home = sr.get('home', {})
    away = sr.get('away', {})
    h_inj = [p['name'] for p in home.get('injuredPlayers', [])]
    a_inj = [p['name'] for p in away.get('injuredPlayers', [])]
    print(f"Match {m['id']}: {m['homeTeam']['name']} (Coach: {home.get('coach')}) vs {m['awayTeam']['name']} (Coach: {away.get('coach')})")
    print('  Home Injured:', h_inj)
    print('  Away Injured:', a_inj)
