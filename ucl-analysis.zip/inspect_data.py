import json, re

with open('data.js', 'r', encoding='utf-8') as f:
    text = f.read()

# remove 'const UCL_DATA = ' and trailing ';'
json_str = text.strip()
if json_str.startswith('const UCL_DATA ='):
    json_str = json_str[len('const UCL_DATA ='):].strip()
if json_str.endswith(';'):
    json_str = json_str[:-1].strip()

data = json.loads(json_str)
print("Matches found:", len(data['matches']))
for m in data['matches']:
    print(f"Match {m['id']}: {m['homeTeam']['name']} vs {m['awayTeam']['name']} (ID: {m['homeTeam']['id']} vs {m['awayTeam']['id']})")
