# -*- coding: utf-8 -*-
import re

# Read current script.js
with open('script.js', 'r', encoding='utf-8') as f:
    script_content = f.read()

# Update renderPlayerRow in script.js to support real photos
old_render_row = """    // Render player row
    function renderPlayerRow(p, teamId) {
      return `
        <div class="injury-player-row">
          <div class="injury-player-left">
            <div class="injury-player-avatar">${p.pos}</div>
            <div class="injury-player-info">
              <div class="injury-player-name">${p.name}</div>
              <div class="injury-player-pos-detail">${p.detail}</div>
            </div>
          </div>
          <span class="injury-player-badge ${getBadgeClass(p.status)}">
            ${p.statusText}
          </span>
        </div>
      `;
    }"""

new_render_row = """    // Render player row (Sofascore style with real face photos)
    function renderPlayerRow(p, teamId) {
      const photoHtml = p.image
        ? `<img src="${p.image}" class="injury-player-photo-img" alt="${p.name}" onerror="this.onerror=null; this.src='assets/logos/${teamId}.png';">`
        : `<span class="pos-fallback">${p.pos}</span>`;

      return `
        <div class="injury-player-row">
          <div class="injury-player-left">
            <div class="injury-player-avatar-wrap">
              ${photoHtml}
              ${p.status === 'Out' ? '<span class="avatar-status-dot dot-out"></span>' : ''}
              ${p.status === 'Suspended' ? '<span class="avatar-status-dot dot-suspended"></span>' : ''}
            </div>
            <div class="injury-player-info">
              <div class="injury-player-name">${p.name}</div>
              <div class="injury-player-pos-detail">${p.detail || p.role || ''}</div>
            </div>
          </div>
          <span class="injury-player-badge ${getBadgeClass(p.status)}">
            ${p.statusText || p.stat || ''}
          </span>
        </div>
      `;
    }"""

if old_render_row in script_content:
    script_content = script_content.replace(old_render_row, new_render_row)
    print("Replaced renderPlayerRow successfully!")
else:
    print("Warning: old_render_row not found exactly, will check regex")

with open('script.js', 'w', encoding='utf-8') as f:
    f.write(script_content)
